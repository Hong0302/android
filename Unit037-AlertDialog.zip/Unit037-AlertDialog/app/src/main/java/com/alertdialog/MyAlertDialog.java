package com.alertdialog;

        import android.content.Context;
        import android.support.v7.app.AlertDialog;

public class MyAlertDialog extends AlertDialog {
    protected MyAlertDialog(Context context) {
        super(context);
    }
}
